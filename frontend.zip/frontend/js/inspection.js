/**
 * DEFECTX AI - Mobile Camera Live Inspection Studio Controller
 * CLOCKIT 2026 Hackathon
 */

(function () {
  'use strict';

  // Sample SVG Data URLs representing genuine MVTec bottles for evaluation
  const SAMPLE_PRESETS = {
    normal: {
      filename: 'bottle_normal_test_018.png',
      type: 'normal',
      isAnomaly: false,
      svg: generateBottleSvg('normal')
    },
    broken_large: {
      filename: 'bottle_broken_large_001.png',
      type: 'broken_large',
      isAnomaly: true,
      svg: generateBottleSvg('broken_large')
    },
    broken_small: {
      filename: 'bottle_broken_small_007.png',
      type: 'broken_small',
      isAnomaly: true,
      svg: generateBottleSvg('broken_small')
    },
    contamination: {
      filename: 'bottle_contamination_004.png',
      type: 'contamination',
      isAnomaly: true,
      svg: generateBottleSvg('contamination')
    }
  };

  function generateBottleSvg(variant) {
    let defectOverlay = '';
    let mainColor = '#00F2FE';

    if (variant === 'broken_large') {
      mainColor = '#EF4444';
      defectOverlay = `
        <path d="M120 180 L95 230 L145 260 L110 320" stroke="#FF4757" stroke-width="6" stroke-linecap="round"/>
        <circle cx="115" cy="245" r="28" fill="rgba(255, 71, 87, 0.35)"/>
      `;
    } else if (variant === 'broken_small') {
      mainColor = '#F59E0B';
      defectOverlay = `
        <circle cx="170" cy="55" r="14" fill="#FF4757" opacity="0.8"/>
        <path d="M165 48 L175 62" stroke="#FFF" stroke-width="3"/>
      `;
    } else if (variant === 'contamination') {
      mainColor = '#F97316';
      defectOverlay = `
        <circle cx="150" cy="290" r="16" fill="#00F2FE"/>
        <circle cx="165" cy="305" r="10" fill="#EF4444"/>
        <circle cx="140" cy="315" r="8" fill="#F59E0B"/>
      `;
    }

    const svgString = `
      <svg width="400" height="400" viewBox="0 0 320 400" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="320" height="400" fill="#060A14"/>
        <line x1="20" y1="200" x2="300" y2="200" stroke="rgba(0,242,254,0.1)" stroke-width="1"/>
        <line x1="160" y1="20" x2="160" y2="380" stroke="rgba(0,242,254,0.1)" stroke-width="1"/>
        <rect x="135" y="40" width="50" height="55" rx="3" fill="#0D182E" stroke="${mainColor}" stroke-width="2.5"/>
        <rect x="130" y="32" width="60" height="12" rx="3" fill="${mainColor}" opacity="0.8"/>
        <path d="M135 95 C135 125 70 155 70 200 L70 340 C70 355 85 370 100 370 L220 370 C235 370 250 355 250 340 L250 200 C250 155 185 125 185 95 Z" fill="#091122" stroke="${mainColor}" stroke-width="3"/>
        <path d="M74 230 C120 240 200 220 246 230 L246 340 C246 352 232 366 220 366 L100 366 C88 366 74 352 74 340 Z" fill="rgba(0, 242, 254, 0.12)"/>
        ${defectOverlay}
      </svg>
    `;
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svgString);
  }

  // State Management
  let activeMode = 'camera'; // 'camera' | 'upload'
  let currentImagePayload = null;
  let currentFilename = 'captured_bottle_specimen.png';
  let isCurrentDefectHint = null;
  let capturedBlob = null;
  let lastInspectionResult = null;
  const selectedCategory = 'bottle'; // Exclusively MVTec Bottle for production reliability

  // Media Stream State
  let activeMediaStream = null;
  let currentFacingMode = 'environment'; // environment for mobile rear, fallback to laptop webcam
  let availableVideoDevices = [];
  let selectedDeviceId = null;

  document.addEventListener('DOMContentLoaded', () => {
    initCameraControls();
    initModeSwitching();
    initPresetSelection();
    initDropzone();
    initRunInspectionTrigger();
    initStageViewTabs();

    // Default: Check if on mobile
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    if (isMobile) {
      setMode('camera');
    } else {
      // Default to sample preset on desktop
      loadSample(SAMPLE_PRESETS.broken_large);
    }
  });

  // =========================================================================
  // 1. Mode Switching (Camera vs Upload Library)
  // =========================================================================
  function initModeSwitching() {
    const tabCamera = document.getElementById('tab-mode-camera');
    const tabUpload = document.getElementById('tab-mode-upload');

    if (tabCamera) {
      tabCamera.addEventListener('click', () => setMode('camera'));
    }
    if (tabUpload) {
      tabUpload.addEventListener('click', () => setMode('upload'));
    }
  }

  function setMode(mode) {
    activeMode = mode;
    const tabCamera = document.getElementById('tab-mode-camera');
    const tabUpload = document.getElementById('tab-mode-upload');
    const secCamera = document.getElementById('section-camera-mode');
    const secUpload = document.getElementById('section-upload-mode');
    const btnRunDesktop = document.getElementById('btn-run-inspection');

    if (mode === 'camera') {
      tabCamera.classList.add('active');
      tabUpload.classList.remove('active');
      secCamera.style.display = 'flex';
      secUpload.style.display = 'none';
      if (btnRunDesktop) btnRunDesktop.style.display = 'none'; // in camera mode, scan button is inside camera card
    } else {
      tabCamera.classList.remove('active');
      tabUpload.classList.add('active');
      secCamera.style.display = 'none';
      secUpload.style.display = 'flex';
      if (btnRunDesktop) btnRunDesktop.style.display = 'flex';
      stopCameraStream();
    }
  }

  // =========================================================================
  // 2. Optical Camera Implementation (Laptop Webcam + Mobile Rear Sensor)
  // =========================================================================
  function initCameraControls() {
    const btnStart = document.getElementById('btn-start-camera');
    const btnCapture = document.getElementById('btn-capture-frame');
    const btnSwitch = document.getElementById('btn-switch-camera');
    const btnStop = document.getElementById('btn-stop-camera');
    const btnRetake = document.getElementById('btn-retake-frame');
    const btnScan = document.getElementById('btn-scan-frame');
    const deviceSelect = document.getElementById('camera-device-select');

    if (btnStart) btnStart.addEventListener('click', startCamera);
    if (btnCapture) btnCapture.addEventListener('click', captureFrame);
    if (btnSwitch) btnSwitch.addEventListener('click', switchCamera);
    if (btnStop) btnStop.addEventListener('click', stopCameraStream);
    if (btnRetake) btnRetake.addEventListener('click', retakeFrame);
    if (btnScan) btnScan.addEventListener('click', () => executeInspection('MOBILE_CAMERA'));

    if (deviceSelect) {
      deviceSelect.addEventListener('change', (e) => {
        selectedDeviceId = e.target.value;
        startCamera();
      });
    }

    refreshDeviceList();

    // Stop camera when navigating away
    window.addEventListener('beforeunload', stopCameraStream);
    window.addEventListener('pagehide', stopCameraStream);
  }

  async function refreshDeviceList() {
    const btnSwitch = document.getElementById('btn-switch-camera');
    const deviceSelect = document.getElementById('camera-device-select');

    if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) return;

    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      availableVideoDevices = devices.filter(d => d.kind === 'videoinput');

      if (deviceSelect) {
        if (availableVideoDevices.length > 1) {
          deviceSelect.innerHTML = '';
          availableVideoDevices.forEach((d, idx) => {
            const opt = document.createElement('option');
            opt.value = d.deviceId;
            opt.textContent = d.label || `Camera ${idx + 1}`;
            if (selectedDeviceId && d.deviceId === selectedDeviceId) opt.selected = true;
            deviceSelect.appendChild(opt);
          });
          deviceSelect.style.display = 'inline-block';
        } else {
          deviceSelect.style.display = 'none';
        }
      }

      if (btnSwitch) {
        btnSwitch.style.display = (availableVideoDevices.length > 1) ? 'inline-flex' : 'none';
      }
    } catch (e) {
      // Ignore enumeration errors until permission is granted
    }
  }

  async function startCamera() {
    const errorBanner = document.getElementById('camera-error-banner');
    const errorText = document.getElementById('camera-error-text');
    const promptCard = document.getElementById('camera-prompt-card');
    const videoElem = document.getElementById('camera-video');
    const reticle = document.getElementById('camera-reticle');
    const liveControls = document.getElementById('camera-live-controls');
    const reviewArea = document.getElementById('captured-review-area');
    const statusText = document.getElementById('camera-status-text');
    const statusDot = document.getElementById('camera-status-dot');
    const feedBadge = document.getElementById('camera-feed-badge');

    if (errorBanner) errorBanner.style.display = 'none';

    // 1. Verify Browser Support
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      showCameraError('Your browser does not support the MediaDevices camera API. Please use Microsoft Edge or Google Chrome.');
      return;
    }

    // 2. Verify Secure Context (Chrome/Edge require HTTPS or localhost)
    const isLocalhost = location.hostname === 'localhost' || location.hostname === '127.0.0.1';
    if (!window.isSecureContext && !isLocalhost) {
      showCameraError('Camera access requires HTTPS or localhost. For mobile testing, run run_mobile.ps1 (which configures an ADB reverse tunnel to http://localhost:8080) or serve over HTTPS.');
      return;
    }

    // Stop existing stream and tracks before requesting a new one
    stopCameraStream();

    // 3. Build constraints: prefer explicit deviceId if selected, otherwise ideal facingMode
    const videoConstraints = {
      width: { ideal: 1920, min: 640 },
      height: { ideal: 1080, min: 480 }
    };

    if (selectedDeviceId) {
      videoConstraints.deviceId = { exact: selectedDeviceId };
    } else {
      videoConstraints.facingMode = { ideal: currentFacingMode };
    }

    const constraints = {
      video: videoConstraints,
      audio: false
    };

    try {
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      activeMediaStream = stream;

      // Configure video element properly per browser video standards
      videoElem.autoplay = true;
      videoElem.muted = true;
      videoElem.playsInline = true;
      videoElem.setAttribute('playsinline', '');
      videoElem.setAttribute('webkit-playsinline', '');
      videoElem.srcObject = stream;

      // Wait for loadedmetadata and video play
      await new Promise((resolve, reject) => {
        const onLoaded = () => {
          videoElem.removeEventListener('loadedmetadata', onLoaded);
          resolve();
        };
        videoElem.addEventListener('loadedmetadata', onLoaded);
        setTimeout(resolve, 1500); // safety fallback
      });

      await videoElem.play();

      // Verify that actual video frames are streaming (dimensions > 0)
      if (videoElem.videoWidth === 0 || videoElem.videoHeight === 0) {
        // Poll for up to 1 second for valid dimensions
        await new Promise(r => {
          let count = 0;
          const interval = setInterval(() => {
            count++;
            if (videoElem.videoWidth > 0 || count > 10) {
              clearInterval(interval);
              r();
            }
          }, 100);
        });
      }

      if (videoElem.videoWidth === 0 || videoElem.videoHeight === 0) {
        throw new Error('Camera feed connected but returned 0x0 frame dimensions.');
      }

      // UI State: Live Streaming Verified
      videoElem.style.display = 'block';
      if (reticle) reticle.style.display = 'flex';
      if (promptCard) promptCard.style.display = 'none';
      if (reviewArea) reviewArea.style.display = 'none';
      if (liveControls) liveControls.style.display = 'flex';

      const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
      const isRear = (currentFacingMode === 'environment');
      const labelText = isMobile
        ? (isRear ? 'LIVE REAR SENSOR' : 'LIVE FRONT SENSOR')
        : 'LIVE WEBCAM STREAM';

      if (statusText) statusText.textContent = labelText;
      if (statusDot) {
        statusDot.className = 'fas fa-circle text-green';
        statusDot.style.boxShadow = '0 0 8px #10B981';
      }
      if (feedBadge) {
        feedBadge.textContent = `${videoElem.videoWidth}x${videoElem.videoHeight}`;
      }

      // Refresh device labels now that permission has been granted
      refreshDeviceList();

      if (window.showToast) {
        window.showToast('Camera Connected', `${labelText} active (${videoElem.videoWidth}x${videoElem.videoHeight}). Align bottle specimen.`, 'success', 3000);
      }
    } catch (err) {
      console.error('Camera access error:', err);
      let msg = 'Failed to access camera: ' + (err.message || err);
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        msg = 'Camera permission was denied. Please allow camera permissions in your browser address bar.';
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        msg = 'No camera hardware found on this system.';
      } else if (err.name === 'NotReadableError' || err.name === 'TrackStartError') {
        msg = 'Camera is already in use by another application. Please close other camera programs and try again.';
      } else if (err.name === 'OverconstrainedError') {
        // Fallback to minimal unconstrained stream if ideal resolution failed
        try {
          const fallbackStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
          activeMediaStream = fallbackStream;
          videoElem.srcObject = fallbackStream;
          await videoElem.play();
          videoElem.style.display = 'block';
          if (promptCard) promptCard.style.display = 'none';
          if (liveControls) liveControls.style.display = 'flex';
          if (statusText) statusText.textContent = 'LIVE OPTICAL FEED';
          if (statusDot) {
            statusDot.className = 'fas fa-circle text-green';
            statusDot.style.boxShadow = '0 0 8px #10B981';
          }
          return;
        } catch (fallbackErr) {
          msg = 'Could not initialize camera feed: ' + fallbackErr.message;
        }
      }
      showCameraError(msg);
      stopCameraStream();
    }
  }

  function showCameraError(msg) {
    const errorBanner = document.getElementById('camera-error-banner');
    const errorText = document.getElementById('camera-error-text');
    if (errorBanner && errorText) {
      errorText.textContent = msg;
      errorBanner.style.display = 'flex';
    }
    if (window.showToast) {
      window.showToast('Camera Notice', msg, 'warning', 6000);
    }
  }

  function switchCamera() {
    selectedDeviceId = null;
    currentFacingMode = (currentFacingMode === 'environment') ? 'user' : 'environment';
    startCamera();
  }

  function stopCameraStream() {
    if (activeMediaStream) {
      activeMediaStream.getTracks().forEach(track => {
        try { track.stop(); } catch (e) { }
      });
      activeMediaStream = null;
    }

    const videoElem = document.getElementById('camera-video');
    const reticle = document.getElementById('camera-reticle');
    const liveControls = document.getElementById('camera-live-controls');
    const promptCard = document.getElementById('camera-prompt-card');
    const statusText = document.getElementById('camera-status-text');
    const statusDot = document.getElementById('camera-status-dot');
    const feedBadge = document.getElementById('camera-feed-badge');

    if (videoElem) {
      try { videoElem.pause(); } catch (e) { }
      videoElem.srcObject = null;
      videoElem.style.display = 'none';
    }
    if (reticle) reticle.style.display = 'none';
    if (liveControls) liveControls.style.display = 'none';
    if (promptCard) promptCard.style.display = 'flex';

    if (statusText) statusText.textContent = 'CAMERA STANDBY';
    if (statusDot) {
      statusDot.className = 'fas fa-circle text-muted';
      statusDot.style.boxShadow = 'none';
    }
    if (feedBadge) feedBadge.textContent = 'SENSOR STANDBY';
  }

  // =========================================================================
  // 3. Capture Frame & Review Stage
  // =========================================================================
  function captureFrame() {
    const videoElem = document.getElementById('camera-video');
    const canvas = document.getElementById('camera-canvas');
    const reviewArea = document.getElementById('captured-review-area');
    const liveControls = document.getElementById('camera-live-controls');
    const previewImg = document.getElementById('captured-preview-img');
    const chamberImg = document.getElementById('preview-stage-img');
    const dimsEl = document.getElementById('captured-dims');
    const sizeEl = document.getElementById('captured-size');
    const metaFilename = document.getElementById('meta-filename');
    const placeholder = document.getElementById('preview-placeholder-box');

    if (!videoElem || !videoElem.videoWidth) {
      if (window.showToast) window.showToast('Capture Error', 'Video stream not ready for capture.', 'error');
      return;
    }

    const width = videoElem.videoWidth;
    const height = videoElem.videoHeight;
    canvas.width = width;
    canvas.height = height;

    const ctx = canvas.getContext('2d');
    ctx.drawImage(videoElem, 0, 0, width, height);

    // Convert frame to Blob and DataURL
    canvas.toBlob((blob) => {
      capturedBlob = blob;
      const sizeKb = (blob.size / 1024).toFixed(1);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.95);

      currentImagePayload = blob;
      currentFilename = `mobile_capture_${Date.now()}.jpg`;
      isCurrentDefectHint = null;

      // Update Review UI
      previewImg.src = dataUrl;
      if (chamberImg) {
        chamberImg.src = dataUrl;
        chamberImg.style.display = 'block';
      }
      if (placeholder) placeholder.style.display = 'none';

      if (dimsEl) dimsEl.textContent = `${width} x ${height} px`;
      if (sizeEl) sizeEl.textContent = `${sizeKb} KB`;
      if (metaFilename) metaFilename.textContent = currentFilename;

      // Switch from live video to captured preview
      videoElem.style.display = 'none';
      const reticle = document.getElementById('camera-reticle');
      if (reticle) reticle.style.display = 'none';
      if (liveControls) liveControls.style.display = 'none';
      if (reviewArea) reviewArea.style.display = 'flex';

      if (window.showToast) {
        window.showToast('Frame Captured', `Resolution: ${width}x${height} (${sizeKb} KB). Inspect and tap SCAN IMAGE.`, 'info', 3000);
      }
    }, 'image/jpeg', 0.95);
  }

  function retakeFrame() {
    capturedBlob = null;
    currentImagePayload = null;
    const reviewArea = document.getElementById('captured-review-area');
    if (reviewArea) reviewArea.style.display = 'none';

    // Clear previous verdict banners
    resetResultsView();

    // Re-engage live camera
    const videoElem = document.getElementById('camera-video');
    const reticle = document.getElementById('camera-reticle');
    const liveControls = document.getElementById('camera-live-controls');

    if (activeMediaStream && videoElem) {
      videoElem.style.display = 'block';
      if (reticle) reticle.style.display = 'flex';
      if (liveControls) liveControls.style.display = 'flex';
    } else {
      startCamera();
    }
  }

  // =========================================================================
  // 4. Run AI Defect Inspection (PHP Backend + Python AI Engine)
  // =========================================================================
  function initRunInspectionTrigger() {
    const btnRunDesktop = document.getElementById('btn-run-inspection');
    if (btnRunDesktop) {
      btnRunDesktop.addEventListener('click', () => executeInspection('WEB_UPLOAD'));
    }
  }

  async function executeInspection(sourceType = 'MOBILE_CAMERA') {
    if (!currentImagePayload) {
      if (window.showToast) {
        window.showToast('No Specimen Loaded', 'Please capture a camera frame or load a benchmark specimen.', 'warning');
      }
      return;
    }

    const modal = document.getElementById('inspection-modal');
    if (modal) modal.classList.add('active');

    // Animate 5-step stepper for responsive visual feedback
    animateStepper();

    try {
      const startTime = performance.now();

      // Upload image to PHP backend (/api/inspect.php) -> Python inference
      const result = await window.DefectXApi.inspectImage(currentImagePayload, currentFilename, isCurrentDefectHint, selectedCategory);

      const elapsed = (performance.now() - startTime).toFixed(1);
      lastInspectionResult = result;

      // Close modal
      setTimeout(() => {
        if (modal) modal.classList.remove('active');
        renderInspectionResult(result);
      }, 700);

    } catch (err) {
      console.error('Inspection failed:', err);
      if (modal) modal.classList.remove('active');
      renderFailedResult(err.message || 'Inspection failed.');
    }
  }

  function animateStepper() {
    const steps = [
      document.getElementById('step-1'),
      document.getElementById('step-2'),
      document.getElementById('step-3'),
      document.getElementById('step-4'),
      document.getElementById('step-5')
    ];

    steps.forEach((s, idx) => {
      if (!s) return;
      s.className = 'stepper-row';
      setTimeout(() => {
        steps.forEach((el, i) => {
          if (!el) return;
          if (i < idx) el.className = 'stepper-row completed';
          else if (i === idx) el.className = 'stepper-row active';
        });
      }, idx * 180);
    });
  }

  function renderInspectionResult(result) {
    if (!result) return;

    const bannerContainer = document.getElementById('result-verdict-banner');
    const stageTabs = document.getElementById('stage-view-tabs');
    const actionsRow = document.getElementById('post-inspection-actions');
    const scoreRow = document.getElementById('meta-score-row');
    const reportLink = document.getElementById('btn-view-full-report');
    const stageImg = document.getElementById('preview-stage-img');

    const score = parseFloat(result.anomaly_score || 0);
    const threshold = parseFloat(result.threshold || 0.6366);
    const pixelThreshold = parseFloat(result.pixel_threshold || 0.5060);
    const scoreDelta = (score - threshold);
    const isAnomaly = (result.prediction === 'ANOMALY') || (score >= threshold);
    const severity = (result.severity || (isAnomaly ? 'HIGH' : 'NONE')).toUpperCase();
    const anomalyScoreStr = score.toFixed(4);
    const thresholdStr = threshold.toFixed(4);
    const deltaSign = scoreDelta >= 0 ? '+' : '';
    const deltaStr = `${deltaSign}${scoreDelta.toFixed(4)}`;

    const areaRatio = result.anomalous_area_ratio !== undefined ? parseFloat(result.anomalous_area_ratio) : (result.details?.anomalous_area_ratio !== undefined ? parseFloat(result.details.anomalous_area_ratio) : 0);
    const areaPct = (areaRatio * 100).toFixed(2);

    const decisionMsg = isAnomaly
      ? `Anomaly detected because the image anomaly score (${anomalyScoreStr}) exceeded the configured decision threshold (${thresholdStr}).`
      : `No anomaly detected because the image anomaly score (${anomalyScoreStr}) did not exceed the configured decision threshold (${thresholdStr}).`;

    // 1. Prominent Verdict & AI Decision Explanation Banner
    if (bannerContainer) {
      bannerContainer.style.display = 'block';
      const borderClass = isAnomaly ? 'danger' : 'success';
      const iconClass = isAnomaly ? 'fa-triangle-exclamation' : 'fa-circle-check';
      const title = isAnomaly ? 'ANOMALY DETECTED – DEFECT FOUND' : 'INSPECTION PASSED – NO ANOMALY DETECTED';
      const deltaBadgeClass = isAnomaly ? 'badge-danger' : 'badge-success';

      bannerContainer.innerHTML = `
        <div class="verdict-banner ${borderClass}" style="flex-direction: column; gap: 12px; align-items: stretch;">
          <div style="display: flex; align-items: flex-start; gap: 14px;">
            <div class="verdict-icon"><i class="fas ${iconClass}"></i></div>
            <div style="flex: 1;">
              <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 6px;">
                <h3 class="verdict-title">${title}</h3>
                <span class="badge ${deltaBadgeClass} font-mono" style="font-size: 0.75rem;">Δ ${deltaStr}</span>
              </div>
              <p class="verdict-sub" style="margin-top: 6px; font-size: 0.88rem; line-height: 1.45; color: #fff;">
                <strong>Decision Logic:</strong> ${decisionMsg}
              </p>
            </div>
          </div>

          <!-- Comparative Telemetry Pill Row -->
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(110px, 1fr)); gap: 8px; background: rgba(0, 0, 0, 0.25); padding: 10px 14px; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle); font-size: 0.75rem;">
            <div>
              <span style="color: var(--text-muted); display: block; font-size: 0.68rem; text-transform: uppercase;">Score (s)</span>
              <strong class="font-mono text-cyan" style="font-size: 0.95rem;">${anomalyScoreStr}</strong>
            </div>
            <div>
              <span style="color: var(--text-muted); display: block; font-size: 0.68rem; text-transform: uppercase;">Threshold (τ)</span>
              <strong class="font-mono" style="color: var(--amber); font-size: 0.95rem;">${thresholdStr}</strong>
            </div>
            <div>
              <span style="color: var(--text-muted); display: block; font-size: 0.68rem; text-transform: uppercase;">Area Exceeding</span>
              <strong class="font-mono" style="color: #fff; font-size: 0.95rem;">${areaPct}%</strong>
            </div>
            <div>
              <span style="color: var(--text-muted); display: block; font-size: 0.68rem; text-transform: uppercase;">Severity Tier</span>
              <span class="badge ${isAnomaly ? 'badge-danger' : 'badge-success'}" style="font-size: 0.7rem; padding: 2px 6px;">${severity}</span>
            </div>
            <div>
              <span style="color: var(--text-muted); display: block; font-size: 0.68rem; text-transform: uppercase;">Confidence</span>
              <span style="color: var(--text-secondary); font-size: 0.72rem;">Uncalibrated (Metric)</span>
            </div>
          </div>

          <!-- Heatmap & Severity Prototype Note -->
          <div style="font-size: 0.7rem; color: var(--text-muted); line-height: 1.4; display: flex; flex-direction: column; gap: 2px;">
            <span><i class="fas fa-info-circle text-cyan"></i> Heatmap highlights localized nearest-neighbor feature patch distance; it does not classify defect categories.</span>
            <span><i class="fas fa-triangle-exclamation" style="color: var(--amber);"></i> Heuristic visual estimate prototype only. Not a verified physical damage measurement.</span>
          </div>
        </div>
      `;
    }

    // 2. Enable Stage View Tabs (Overlay / Heatmap / Original)
    if (stageTabs) stageTabs.style.display = 'flex';
    if (actionsRow) actionsRow.style.display = 'flex';

    if (reportLink && result.inspection_id) {
      reportLink.href = `results.html?id=${encodeURIComponent(result.inspection_id)}`;
    }

    // 3. Update Image Display with Blended Overlay
    const overlaySrc = result.overlay_path || result.heatmap_path || result.original_image;
    if (stageImg && overlaySrc) {
      stageImg.src = overlaySrc;
    }

    // 4. Update Specs Table
    if (scoreRow) {
      scoreRow.innerHTML = isAnomaly
        ? `<span class="badge badge-danger">${anomalyScore}</span> <span class="badge badge-danger">${severity}</span>`
        : `<span class="badge badge-success">${anomalyScore}</span> <span class="badge badge-success">PASS</span>`;
    }

    // Toast Notification
    if (window.showToast) {
      const toastType = isAnomaly ? 'error' : 'success';
      const toastTitle = isAnomaly ? 'ANOMALY DETECTED' : 'INSPECTION PASSED';
      window.showToast(toastTitle, `Score: ${anomalyScore} | Severity: ${severity} | ${result.processing_time_ms}ms`, toastType, 5000);
    }
  }

  function renderFailedResult(errMessage) {
    const bannerContainer = document.getElementById('result-verdict-banner');
    if (bannerContainer) {
      bannerContainer.style.display = 'block';
      bannerContainer.innerHTML = `
        <div class="verdict-banner danger">
          <div class="verdict-icon"><i class="fas fa-circle-xmark"></i></div>
          <div style="flex: 1;">
            <h3 class="verdict-title">INSPECTION FAILED – PLEASE TRY AGAIN</h3>
            <p class="verdict-sub">${errMessage || 'An error occurred during Python AI inference execution.'}</p>
          </div>
        </div>
      `;
    }
    if (window.showToast) {
      window.showToast('Inspection Failed', 'INSPECTION FAILED – PLEASE TRY AGAIN', 'error', 5000);
    }
  }

  function resetResultsView() {
    const bannerContainer = document.getElementById('result-verdict-banner');
    const stageTabs = document.getElementById('stage-view-tabs');
    const actionsRow = document.getElementById('post-inspection-actions');
    const scoreRow = document.getElementById('meta-score-row');

    if (bannerContainer) bannerContainer.style.display = 'none';
    if (stageTabs) stageTabs.style.display = 'none';
    if (actionsRow) actionsRow.style.display = 'none';
    if (scoreRow) scoreRow.textContent = 'Awaiting Scan';
  }

  // =========================================================================
  // 5. Stage View Modes (Overlay / Heatmap / Original)
  // =========================================================================
  function initStageViewTabs() {
    const buttons = document.querySelectorAll('[data-stage-view]');
    const stageImg = document.getElementById('preview-stage-img');

    buttons.forEach(btn => {
      btn.addEventListener('click', () => {
        buttons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        const view = btn.getAttribute('data-stage-view');
        if (!lastInspectionResult) return;

        if (view === 'overlay') {
          stageImg.src = lastInspectionResult.overlay_path || lastInspectionResult.original_image;
        } else if (view === 'heatmap') {
          stageImg.src = lastInspectionResult.heatmap_path || lastInspectionResult.original_image;
        } else if (view === 'original') {
          stageImg.src = lastInspectionResult.original_image;
        }
      });
    });
  }

  // =========================================================================
  // 6. Benchmark Sample Presets & File Dropzone
  // =========================================================================
  function loadSample(preset) {
    currentImagePayload = preset.svg;
    currentFilename = preset.filename;
    isCurrentDefectHint = preset.isAnomaly;
    capturedBlob = null;

    const imgEl = document.getElementById('preview-stage-img');
    const placeholder = document.getElementById('preview-placeholder-box');
    const metaFilename = document.getElementById('meta-filename');

    if (imgEl) {
      imgEl.src = preset.svg;
      imgEl.style.display = 'block';
    }
    if (placeholder) placeholder.style.display = 'none';
    if (metaFilename) metaFilename.textContent = preset.filename;
    resetResultsView();
  }

  function initPresetSelection() {
    const items = document.querySelectorAll('.preset-card-item');
    items.forEach(item => {
      item.addEventListener('click', () => {
        items.forEach(i => i.classList.remove('active'));
        item.classList.add('active');

        const type = item.getAttribute('data-sample-type');
        if (SAMPLE_PRESETS[type]) {
          loadSample(SAMPLE_PRESETS[type]);
        }
      });
    });
  }

  function initDropzone() {
    const dropzone = document.getElementById('inspection-dropzone');
    const fileInput = document.getElementById('file-input-elem');
    const btnBrowse = document.getElementById('btn-browse-file');

    if (!dropzone || !fileInput) return;

    btnBrowse.addEventListener('click', () => fileInput.click());
    dropzone.addEventListener('click', (e) => {
      if (e.target !== btnBrowse && !btnBrowse.contains(e.target)) {
        fileInput.click();
      }
    });

    ['dragenter', 'dragover'].forEach(eventName => {
      dropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        dropzone.classList.add('dragover');
      });
    });

    ['dragleave', 'drop'].forEach(eventName => {
      dropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        dropzone.classList.remove('dragover');
      });
    });

    dropzone.addEventListener('drop', (e) => {
      const files = e.dataTransfer.files;
      if (files && files.length > 0) {
        handleUploadedFile(files[0]);
      }
    });

    fileInput.addEventListener('change', () => {
      if (fileInput.files && fileInput.files.length > 0) {
        handleUploadedFile(fileInput.files[0]);
      }
    });
  }

  function handleUploadedFile(file) {
    if (!file.type.startsWith('image/')) {
      if (window.showToast) window.showToast('Invalid File', 'Please upload a valid optical image.', 'error');
      return;
    }

    currentImagePayload = file;
    currentFilename = file.name;
    isCurrentDefectHint = null;
    capturedBlob = null;

    const reader = new FileReader();
    reader.onload = (e) => {
      const stageImg = document.getElementById('preview-stage-img');
      const placeholder = document.getElementById('preview-placeholder-box');
      const metaFilename = document.getElementById('meta-filename');

      if (stageImg) {
        stageImg.src = e.target.result;
        stageImg.style.display = 'block';
      }
      if (placeholder) placeholder.style.display = 'none';
      if (metaFilename) metaFilename.textContent = file.name;
      resetResultsView();

      if (window.showToast) {
        window.showToast('File Loaded', `${file.name} ready for inspection.`, 'info');
      }
    };
    reader.readAsDataURL(file);
  }

})();
